# -*- coding: utf-8 -*-
import os, urllib, xbmc, zipfile

def ExtractAll(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		print str(e)
		return False

	return True


def Exodus_Settings():
		
	url = "https://github.com/kobiko3030/senyor-repo/blob/master/addons_senyor_tools/addons_auto_settings/exodus_settings.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos") 	
	
def Salts_Settings():
		
	url = "https://github.com/kobiko3030/senyor-repo/blob/master/addons_senyor_tools/salts_auto-settings/salts_auto-settings.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos") 		
	
def Meta_Settings():
		
	url = "https://github.com/kobiko3030/senyor-repo/blob/master/addons_senyor_tools/metatools/metatools-1.0.0.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos") 		

def Specto_Settings():
		
	url = "https://github.com/kobiko3030/senyor-repo/blob/master/addons_senyor_tools/addons_auto_settings/specto_settings.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos") 		

def Pvr_Settings():
		
	url = "https://github.com/kobiko3030/senyor-repo/blob/master/addons_senyor_tools/pvranarchitv.senyortools/pvranarchitv.senyortools.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos") 			
	
