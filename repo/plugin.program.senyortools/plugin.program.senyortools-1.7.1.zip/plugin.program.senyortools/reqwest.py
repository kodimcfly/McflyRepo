# -*- coding: utf-8 -*-
import os, urllib, xbmc, zipfile, time,xbmcgui

dialog = xbmcgui.Dialog()
Progress = xbmcgui.DialogProgress()

def ExtractAll(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		print str(e)
		return False

	return True

def requestsen():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.requests')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.module.requests')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'script.module.requests')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'script.module.requests')	
			

def requests():

	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.module.requests')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/allinaddons/dependencies/script.module.requests.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")
	time.sleep(2)
	requestsen()
	time.sleep(2)