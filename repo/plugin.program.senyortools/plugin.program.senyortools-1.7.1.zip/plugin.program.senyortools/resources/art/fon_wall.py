# -*- coding: utf-8 -*-
import json
import xbmc, xbmcgui, xbmcaddon
import time

dialog = xbmcgui.Dialog()
Progress = xbmcgui.DialogProgress()

jsonSetrss = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.enablerssfeeds","value":true}, "id":1}'
jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'
jsonSetsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"Hebrew"},"id":1}'
jsonSetqewr = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.keyboardlayouts","value":["Hebrew QWERTY","English QWERTY"]},"id":1}'
jsonSetlan = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.he_il"}, "id":1}'
jsonSettorec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.thewiz"},"id":1}'
jsonSettorectv = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.thewiz"},"id":1}'
jsonSetfirst = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.downloadfirst","value":true},"id":1}'
jsonSethe = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":44},"id":1}'
jsonSethebsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["Hebrew"]},"id":1}'
jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'









def he_walls():
    xbmc.executeJSONRPC(jsonSettorec)
    xbmc.executeJSONRPC(jsonSettorectv)
    xbmc.executeJSONRPC(jsonSethebsub)
    xbmc.executeJSONRPC(jsonSetlan)	
    xbmc.executeJSONRPC(jsonSetFont)		

def en_walls():
        xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyortools/resources/art/wall.py)')
        time.sleep(10)
        dialog.ok('אשף הגדרת הקודי ','במסך הבא הגדירו את ספריית הסרטים והסדרות')	
        xbmc.executebuiltin('RunScript(plugin.video.thewiz.wall,0,0)')
	

def ru_walls():	
    dialog.ok('אשף הגדרת הקודי ','התקנת הרחבות בקליק','במסך הבא בחרו את ההרחבות שתרצו להתקין')	
    xbmc.executebuiltin('RunScript(plugin.program.repotools)')

	
def prsb():
    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])


    if version >= 15.0 and version <= 15.9:
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyortools/resources/art/ltr.py)')
    if version >= 16.0 and version <= 16.9:
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyortools/resources/art/ltr.py)')
    if version >= 17.0 and version <= 17.9:
		pass

	
def prs(): 
    Progress.create("מגדיר ומפעיל לקוח טלוויזיה חיה", "נא להמתין...")
    Progress.update(0)
    addonsettings.Prvr_Settings() 
    Progress.update(100)
    videoAddon.prset() 
    prsb()
    Updates()

      
xbmc.executebuiltin("UpdateLocalAddons")
xbmc.executebuiltin("UpdateAddonRepos")      
dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  קיר הסרטים הותקן " ,"","")  

	
