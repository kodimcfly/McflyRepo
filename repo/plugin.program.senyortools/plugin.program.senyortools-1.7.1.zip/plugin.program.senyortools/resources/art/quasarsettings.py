# -*- coding: utf-8 -*-
import os, urllib, xbmc, zipfile, time,xbmcgui, sys

dialog = xbmcgui.Dialog()
Progress = xbmcgui.DialogProgress()

def ExtractAll(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		print str(e)
		return False

	return True

def rarbagmc():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.quasar.rarbg-mc')):
    dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  אותרו ספקי קוואזר ישנים. " ,"נא להסירם לפני ההתקנה.","לחץ אישור ותועבר לעמוד הסרתם.") 
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.program.senyortools/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cresources%5cart%5cdelete3.png&mode=39&name=%d7%94%d7%a1%d7%a8%d7%aa%20%d7%a1%d7%a4%d7%a7%d7%99%d7%9d%20Quasar&url=script.quasar.)")
    sys.exit(1)
	
def kickassmc():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.quasar.kickass-mc')):
    dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  אותרו ספקי קוואזר ישנים. " ,"נא להסירם לפני ההתקנה.","לחץ אישור ותועבר לעמוד הסרתם.") 
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.program.senyortools/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cresources%5cart%5cdelete3.png&mode=39&name=%d7%94%d7%a1%d7%a8%d7%aa%20%d7%a1%d7%a4%d7%a7%d7%99%d7%9d%20Quasar&url=script.quasar.)")
    sys.exit(1)

def thepiratebaymc():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.quasar.thepiratebay-mc')):
    dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  אותרו ספקי קוואזר ישנים. " ,"נא להסירם לפני ההתקנה.","לחץ אישור ותועבר לעמוד הסרתם.") 
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.program.senyortools/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cresources%5cart%5cdelete3.png&mode=39&name=%d7%94%d7%a1%d7%a8%d7%aa%20%d7%a1%d7%a4%d7%a7%d7%99%d7%9d%20Quasar&url=script.quasar.)")
    sys.exit(1)

def yifymc():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.quasar.yify-mc')):
    dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  אותרו ספקי קוואזר ישנים. " ,"נא להסירם לפני ההתקנה.","לחץ אישור ותועבר לעמוד הסרתם.") 
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.program.senyortools/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cresources%5cart%5cdelete3.png&mode=39&name=%d7%94%d7%a1%d7%a8%d7%aa%20%d7%a1%d7%a4%d7%a7%d7%99%d7%9d%20Quasar&url=script.quasar.)")
    sys.exit(1)
	
def eztvmc():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.quasar.eztv-mc')):
    dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  אותרו ספקי קוואזר ישנים. " ,"נא להסירם לפני ההתקנה.","לחץ אישור ותועבר לעמוד הסרתם.") 
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.program.senyortools/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cresources%5cart%5cdelete3.png&mode=39&name=%d7%94%d7%a1%d7%a8%d7%aa%20%d7%a1%d7%a4%d7%a7%d7%99%d7%9d%20Quasar&url=script.quasar.)")
    sys.exit(1)
	
def extratorrentmc():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.quasar.extratorrent-mc')):
    dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  אותרו ספקי קוואזר ישנים. " ,"נא להסירם לפני ההתקנה.","לחץ אישור ותועבר לעמוד הסרתם.") 
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.program.senyortools/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cresources%5cart%5cdelete3.png&mode=39&name=%d7%94%d7%a1%d7%a8%d7%aa%20%d7%a1%d7%a4%d7%a7%d7%99%d7%9d%20Quasar&url=script.quasar.)")
    sys.exit(1)

def btjunkiemc():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.quasar.btjunkie-mc')):
    dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  אותרו ספקי קוואזר ישנים. " ,"נא להסירם לפני ההתקנה.","לחץ אישור ותועבר לעמוד הסרתם.") 
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.program.senyortools/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cresources%5cart%5cdelete3.png&mode=39&name=%d7%94%d7%a1%d7%a8%d7%aa%20%d7%a1%d7%a4%d7%a7%d7%99%d7%9d%20Quasar&url=script.quasar.)")
    sys.exit(1)

def treexmc():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.quasar.1333x-mc')):
    dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  אותרו ספקי קוואזר ישנים. " ,"נא להסירם לפני ההתקנה.","לחץ אישור ותועבר לעמוד הסרתם.") 
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.program.senyortools/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cresources%5cart%5cdelete3.png&mode=39&name=%d7%94%d7%a1%d7%a8%d7%aa%20%d7%a1%d7%a4%d7%a7%d7%99%d7%9d%20Quasar&url=script.quasar.)")
    sys.exit(1)	
	
def magnetdlmc():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.quasar.magnetdl-mc')):
    dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  אותרו ספקי קוואזר ישנים. " ,"נא להסירם לפני ההתקנה.","לחץ אישור ותועבר לעמוד הסרתם.") 
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.program.senyortools/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cresources%5cart%5cdelete3.png&mode=39&name=%d7%94%d7%a1%d7%a8%d7%aa%20%d7%a1%d7%a4%d7%a7%d7%99%d7%9d%20Quasar&url=script.quasar.)")
    sys.exit(1)

def torrentzmc():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.quasar.torrentz-mc')):
    dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  אותרו ספקי קוואזר ישנים. " ,"נא להסירם לפני ההתקנה.","לחץ אישור ותועבר לעמוד הסרתם.") 
    xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.program.senyortools/?description&fanart=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cfanart.jpg&iconimage=C%3a%5cUsers%5cuser%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.program.senyortools%5cresources%5cart%5cdelete3.png&mode=39&name=%d7%94%d7%a1%d7%a8%d7%aa%20%d7%a1%d7%a4%d7%a7%d7%99%d7%9d%20Quasar&url=script.quasar.)")
    sys.exit(1)	
	
	
def quasarset():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/quasarwizard/userdata/userdata.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	
			
