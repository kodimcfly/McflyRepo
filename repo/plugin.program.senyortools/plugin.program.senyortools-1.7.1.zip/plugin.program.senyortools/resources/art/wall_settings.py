# -*- coding: utf-8 -*-
import os, urllib, xbmc, zipfile, time,xbmcgui, sys, xbmcaddon
import json


dialog = xbmcgui.Dialog()
Progress = xbmcgui.DialogProgress()

def ExtractAll(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		print str(e)
		return False

	return True

	
jsonSetrss = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.enablerssfeeds","value":true}, "id":1}'
jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'
jsonSetsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"Hebrew"},"id":1}'
jsonSetqewr = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.keyboardlayouts","value":["Hebrew QWERTY","English QWERTY"]},"id":1}'
jsonSetlan = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.he_il"}, "id":1}'
jsonSettorec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.thewiz"},"id":1}'
jsonSettorectv = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.thewiz"},"id":1}'
jsonSetfirst = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.downloadfirst","value":true},"id":1}'
jsonSethe = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":44},"id":1}'
jsonSethebsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["Hebrew"]},"id":1}'
jsonSetensub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["English"]},"id":1}'
jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'
jsonSetopen = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.opensubtitles"},"id":1}'
jsonSetopentv = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.opensubtitles"},"id":1}'
jsonSetrusub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["Russian"]},"id":1}'
jsonSetlanru = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.ru_ru"}, "id":1}'

def he_walls():
    xbmc.executeJSONRPC(jsonSettorec)
    xbmc.executeJSONRPC(jsonSettorectv)
    xbmc.executeJSONRPC(jsonSethebsub)
    xbmc.executeJSONRPC(jsonSetlan)	
    xbmc.executeJSONRPC(jsonSetFont)	

def en_walls():
    xbmc.executeJSONRPC(jsonSetopen)
    xbmc.executeJSONRPC(jsonSetopentv)
    xbmc.executeJSONRPC(jsonSetensub)
    xbmc.executeJSONRPC(jsonSetlanenglish)	
    #xbmc.executeJSONRPC(jsonSetFontenglish)	

def ru_walls():
    xbmc.executeJSONRPC(jsonSetopen)
    xbmc.executeJSONRPC(jsonSetopentv)
    #xbmc.executeJSONRPC(jsonSetrusub)
    #xbmc.executeJSONRPC(jsonSetlanru)	
		

	
def he_data():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizardrepo/he_wall/he_wall-1.0.0.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	
		
def ru_data():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizardrepo/ru_wall/ru_wall-1.0.0.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	

def en_data():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizardrepo/en_wall/en_wall-1.0.0.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass			
			
